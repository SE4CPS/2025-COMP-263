const { MongoClient } = require("mongodb");
const crypto = require("crypto");

const uri = "mongodb+srv://comp263:c4paJkdsceytNEbr@lab2cluster.yub3wro.mongodb.net/";
const client = new MongoClient(uri);

async function run() {
  try {
    await client.connect();
    const db = client.db("Lab2");
    const collection = db.collection("Agriculture");

    const metadata = {
      author: "Jupalli Bhavanand",  
      last_sync: new Date().toISOString(),
      uuid_source: crypto.randomUUID()
    };

    const data = Array(10).fill(null).map((_, i) => ({
      id: i + 1,
      sensorId: `sensor-${i + 1}`,
      reading: Math.floor(Math.random() * 100),
      timestamp: new Date().toISOString(),  // UTC
      notes: `Reading ${i + 1}`,
      ...metadata
    }));

 
    await collection.insertMany(data);

    console.log(" Added 10 new objects (each with metadata) into MongoDB Atlas");
  } catch (err) {
    console.error(" Error inserting data:", err);
  } finally {
    await client.close();
  }
}

run();
